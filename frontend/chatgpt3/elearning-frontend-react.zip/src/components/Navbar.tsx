import { Link, NavLink } from 'react-router-dom'
import useAuthStore from '@stores/auth'

export default function Navbar() {
  const { user, logout } = useAuthStore()
  return (
    <header className="bg-white border-b border-gray-100">
      <div className="container-app flex items-center h-16 gap-4">
        <Link to="/courses" className="text-lg font-semibold text-gray-900">🎓 E‑Learn</Link>
        <nav className="ml-auto flex items-center gap-4">
          <NavLink to="/courses" className="nav-link">Courses</NavLink>
          {user && <NavLink to="/profile" className="nav-link">Profile</NavLink>}
          {user?.role === 'INSTRUCTOR' && <NavLink to="/instructor" className="nav-link">Instructor</NavLink>}
          {user?.role === 'ADMIN' && <NavLink to="/admin" className="nav-link">Admin</NavLink>}
          {!user ? (
            <>
              <Link to="/login" className="btn btn-secondary">Login</Link>
              <Link to="/register" className="btn btn-primary">Sign up</Link>
            </>
          ) : (
            <button onClick={logout} className="btn btn-secondary">Logout</button>
          )}
        </nav>
      </div>
    </header>
  )
}