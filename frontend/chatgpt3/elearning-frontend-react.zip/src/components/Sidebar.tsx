import { NavLink } from 'react-router-dom'
export default function Sidebar() {
  return (
    <aside className="hidden md:block w-64 border-r border-gray-100 bg-white">
      <div className="p-4 space-y-2">
        <h3 className="text-sm font-semibold text-gray-500 uppercase">Dashboard</h3>
        <NavLink to="/profile" className="block nav-link">My Profile</NavLink>
        <NavLink to="/instructor" className="block nav-link">Instructor</NavLink>
        <NavLink to="/admin" className="block nav-link">Admin</NavLink>
      </div>
    </aside>
  )
}