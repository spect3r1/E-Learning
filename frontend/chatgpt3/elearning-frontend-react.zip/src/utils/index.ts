// Add shared utilities here
